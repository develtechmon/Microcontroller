from huskylensPythonLibrary import HuskyLensLibrary
import time

husky = HuskyLensLibrary("I2C") ## SERIAL OR I2C 

while True:
    result = husky.command_request()
    value = ""
    for i in range(4):
        if result[i][4] == 10:
            result[i][4] = 0
        elif result[i][4] == 0:
            result[i][4] = "?"
        value += str(result[i][4])
    print(value)
    #time.sleep(0.3)







