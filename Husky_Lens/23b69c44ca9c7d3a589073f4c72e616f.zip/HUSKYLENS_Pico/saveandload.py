from huskylensPythonLibrary import HuskyLensLibrary
husky = HuskyLensLibrary("I2C")
#husky.command_request_save_model_to_SD_card(4)
husky.command_request_load_model_from_SD_card(1)