# Android-Object-Tracking-OpenCV

# Demonstration:
[![ESP32-CAM: Simple AI Robot (Object Detection | Object Tracking | Lane Tracking)](http://img.youtube.com/vi/J4Bvrvfg920/0.jpg)](https://www.youtube.com/watch?v=J4Bvrvfg920 "Simple Object Tracking Camera Android OpenCV DIY")
